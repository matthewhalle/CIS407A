~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
evasi0n 1.0 (c) 2013 @evad3rs
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

http://evasi0n.com/


DESCRIPTION:

- evasi0n 1.0 is an untethered jailbreak for all iPhone, iPod touch, iPad and iPad mini models running iOS 6.0 through 6.1


SYSTEM REQUIREMENTS:

- MacOSX 10.5/10.6/10.7/10.8
- Windows (XP minimum)
- Linux x86/x86_64 (Kernel >= 2.6.24, libgtk+-2.0 >= 2.24.13)


SUPPORTED FIRMWARES:

- iOS 6.0, 6.0.1, 6.0.2, and 6.1


INSTRUCTIONS:

- Backup your device using iTunes (or iCloud) before using evasi0n. If something breaks, you'll always be able to recover your data.
- Those who use backup passwords in iTunes must disable them for now.  After doing so, iTunes makes a brand new backup.  Please wait for that backup to complete before proceeding!  Feel free to re-enable your backup password after jailbreaking.
- Please disable the lock passcode of your iOS device before using evasi0n. It can cause issues.
- Launch evasi0n, plug in your device, and click "Jailbreak". Just sit back and observe its progress.  Watch for any steps you may be asked to perform.
- Avoid all iOS and iTunes related tasks until evasi0n is complete. Why not just enjoy a brief break from the computer to stretch your legs?
- If the process gets stuck somewhere, it's safe to restart the program, reboot the device (if necessary by holding down Power and Home until it shuts down), and rerun the process.


FAQ:

If you have any questions regarding the jailbreak process or jailbreaking in general 
please go to the Jailbreak QA dedicated website: http://www.jailbreakqa.com
or see their help page for evasi0n: http://www.jailbreakqa.com/pages/evasi0n-help
or try /r/jailbreak on Reddit: http://reddit.com/r/jailbreak


CREDITS:

evasi0n is a production of @evad3rs. http://evad3rs.com


THANKS TO:

- @phoenixdev for his research
- @Surenix for evad3rs and evasi0n designs
- Hanene Samara for her work on evasi0n GUI
- @chronicdevteam and @iphone_dev for their support
- Kiki the cat for the inspiration

