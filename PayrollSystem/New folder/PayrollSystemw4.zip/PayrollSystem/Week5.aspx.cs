﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace PayrollSystem
{
    public partial class Week5 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            UpdateDB("update halleaccounts set balance  = 1000 where accountid =1");
           
        }
        private void UpdateDB(string SQL)
        {
            var conn = new SqlConnection();
            string conectionstring = System.Configuration.ConfigurationManager.ConnectionStrings[1].ToString();
            conn.ConnectionString = conectionstring;
            conn.Open();
            var comm = new SqlCommand();
            comm.Connection = conn;
            comm.CommandText = SQL;
            comm.ExecuteNonQuery();
            conn.Close();
        }

    }
}